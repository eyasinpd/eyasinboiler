# Front End Development Quick Start pack
---


## Feature
--- 

* Boilerplate html5
* Bootstrap v3.3.7 
* Font Awesome v4.7.0
* Normalize Css
* JQuery v3.2.0
* 404 page
* Favicon Icon

### Extra Plugin
---

* WoW.js
* Animate.Css
* Hover Css
* Owl Carousel v2.2.1
* Magnific Popup